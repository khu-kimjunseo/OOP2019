/*
���ʹ��� 1��

#include<iostream>
using namespace std;

int square(int a);

int main() {
	int x;
	x = 5;
	cout << square(x) << endl;
}

int square(int a) {
	return a * a;
}
*/

/*
���ʹ��� 2��

#include <iostream>
using namespace std;

int get_num();
int myadd(int x, int y);
int mysub(int x, int y);
int mymul(int x, int y);
float mydiv(int x, int y);

int main() {
	int x, y;
	x = get_num();
	y = get_num();
	cout << "x = " << x << ", y = " << y << endl;
	cout << "x + y = " << myadd(x, y) << endl;
	cout << "x - y = " << mysub(x, y) << endl;
	cout << "x * y = " << mymul(x, y) << endl;
	cout << "x / y = " << mydiv(x, y) << endl;

	return 0;
}

int get_num() {
	int num;
	cout << "Enter a number: ";
	cin >> num;
	return num;
}

int myadd(int x, int y) {
	return x + y;
}

int mysub(int x, int y) {
	return x - y;
}

int mymul(int x, int y) {
	return x * y;
}

float mydiv(int x, int y) {
	return float(x) / y;
}
*/

/*
���ʹ��� 3��

#include<iostream>
#include<cmath>
using namespace std;

int main() {
	double value;
	value = 5;
	cout << sqrt(value) << endl;
	cout << exp(value) << endl;
	cout << log(value) << endl;
	cout << cos(value) << endl;

	return 0;
}
*/

/*
���ʹ��� 4��

#include <iostream>
using namespace std;

void applePrice(int a = 1000) {
	cout << "Price of an apple is " << a << endl;
}

int main() {
	applePrice(1500);
	applePrice(500);
	applePrice(1000);
	applePrice();

	return 0;
}
*/

/*
���빮�� 1��

#include <iostream>
using namespace std;

int myadd(int a, int b);
int mysub(int a, int b);
int mymul(int a, int b);
float mydiv(int a, int b);
int addmul(int x, int y, int z);
float muldiv(int x, int y, int z);
int addmuladd(int x, int y, int z);
float subdivsub(int x, int y, int z);

int main() {
	int x, y, z;
	cout << "Enter a number: ";
	cin >> x;
	cout << "Enter a number: ";
	cin >> y;
	cout << "Enter a number: ";
	cin >> z;
	cout << "x = " << x << ", y = " << y << ", z = " << z << endl;
	cout << "(x + y) * z = " << addmul(x, y, z) << endl;
	cout << "(x * y) / z = " << muldiv(x, y, z) << endl;
	cout << "(x + y) * (y + z) = " << addmuladd(x, y, z) << endl;
	cout << "(x - y) / (y - z) = " << subdivsub(x, y, z) << endl;
}

int myadd(int a, int b) {
	return a + b;
}
int mysub(int a, int b) {
	return a - b;
}
int mymul(int a, int b) {
	return a * b;
}
float mydiv(int a, int b) {
	return float(a) / b;
}
int addmul(int x, int y, int z) {
	return mymul(myadd(x, y), z);
}
float muldiv(int x, int y, int z) {
	return mydiv(float(mymul(x, y)), z);
}
int addmuladd(int x, int y, int z) {
	return mymul(myadd(x, y), myadd(y, z));
}
float subdivsub(int x, int y, int z) {
	return mydiv(float(mysub(x, y)), mysub(y, z));
}
*/

/*
���빮�� 2��

#include<iostream>
using namespace std;

void print_DOB(int year = 1990, int month = 1, int day = 1);

int main() {
	int x, y, z;
	print_DOB();
	cout << "year �Է� : ";
	cin >> x;
	cout << "month �Է� : ";
	cin >> y;
	cout << "day �Է� : ";
	cin >> z;
	print_DOB(x, y, z);

	return 0;

}

void print_DOB(int year, int month, int day) {
	cout << "��������� " << year << "�� " << month << "�� " << day << "���Դϴ�." << endl;
}
*/

/*
���빮�� 3��

#include<iostream>
#include<cmath>
using namespace std;

int main() {
	double x, y;
	cout << "x = ";
	cin >> x;
	cout << "y = ";
	cin >> y;
	cout << "Rounding up number of " << x << ": " << ceil(x) << endl;
	cout << "Rounding down number of " << x << " :" << floor(x) << endl;
	cout << "Rounding number of " << x << ": " << round(x) << endl;
	cout << "Maximum number between " << x << " and " << y << ": " << fmax(x, y) << endl;
	cout << y << "th root of " << x << ": " << pow(x, 1 / y) << endl;
	cout << "|" << x << " - " << y << "| = " << fabs(x - y) << endl;

	return 0;
}

*/

/*
���빮�� 4��

#include<iostream>
using namespace std;

void get_data(int& x, int& y);
void swap_call_by_value(int x, int y);
void swap_call_by_reference(int& x, int& y);

int main() {
	int x, y;
	get_data(x, y);

	cout << "\nswap_call_by_value �Լ� ��� ��" << endl;
	cout << "x = " << x << ", y = " << y << endl;
	swap_call_by_value(x, y);
	cout << "swap_call_by_value �Լ� ��� ��" << endl;
	cout << "x = " << x << ", y = " << y << endl;

	cout << "\nswap_call_by_reference �Լ� ��� ��" << endl;
	cout << "x = " << x << ", y = " << y << endl;
	swap_call_by_reference(x, y);
	cout << "swap_call_by_reference �Լ� ��� ��" << endl;
	cout << "x = " << x << ", y = " << y << endl;


	return 0;
}

void get_data(int& x, int& y) {
	cout << "x �Է� : ";
	cin >> x;
	cout << "y �Է� : ";
	cin >> y;
}

void swap_call_by_value(int x, int y) {
	int temp = x;
		x = y;
		y = temp;
}

void swap_call_by_reference(int& x, int& y) {
	int temp = x;
		x = y;
		y = temp;
}
*/