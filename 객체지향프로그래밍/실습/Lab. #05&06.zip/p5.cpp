#include<iostream>
#include<iomanip>
using namespace std;

int main() {
	int n, m;
	cout << "Enter n for n x m matrix: ";
	cin >> n;
	cout << "Enter m for n x m matrix: ";
	cin >> m;

	for (int col = 1; col <= n; col++) {
		for (int row = 1; row <= m; row++) {
			int val = col * row;
			cout << setw(4) << val;
		}
		cout << endl;
	}
	return 0;
}