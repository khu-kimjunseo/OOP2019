#include<iostream>
#include<string>
using namespace std;

int main() {
	string s1, s2, s3, s4;
	cout << "�� : ";
	cin >> s1;
	cout << "�� : ";
	cin >> s2;
	cout << "�� : ";
	cin >> s3;
	cout << "�ǹ��� : ";
	cin >> s4;
	s1 = s1 + s2 + s3 + s4;
	
	cout << endl << "�� �ּ� : " << s1 << endl;

	return 0;
}