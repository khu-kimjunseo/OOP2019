#include<iostream>
#include<fstream>
#include<cstdlib>
#include<time.h>
#include<iomanip>
using namespace std;

int main() {
	ofstream fout("txt1.txt");
	srand(time(NULL));
	for (int row = 0; row <= 10; row++) {
		for (int col = 0; col <= 10; col++) {
			fout << setw(4) << rand() % 100 + 1;
		}
		fout << endl;
	}

	fout.close();

	return 0;
	

}