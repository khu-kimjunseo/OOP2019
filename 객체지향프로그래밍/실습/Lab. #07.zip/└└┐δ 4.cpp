#include<iostream>
#include<string>
#include<fstream>
using namespace std;

int main() {
	ofstream fout("temp.txt");
	ifstream fin("txt1.txt");
	string str;
	while (getline(fin, str))
		fout << str << endl;
	fin.close();

	fout << '\n';

	fin.open("txt2.txt");
	while (getline(fin, str))
		fout << str << endl;
	fin.close();

	fout.close();
	
}