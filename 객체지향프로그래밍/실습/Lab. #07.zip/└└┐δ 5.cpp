#include<iostream>
#include<string>
#include<fstream>
#include<iomanip>
using namespace std;

int main() {
	int n, i = 0, m = 1;
	cout << "length = ";
	cin >> n;

	char ch;
	string temp = "";
	ifstream fin("txt1.txt");
	ofstream fout("txt2.txt");

	if (!fin) {
		cout << "Error : no such file exists" << endl;
		exit(100);
	}

	while (true) {
		fin.get(ch);
		if (ch == '\n')
			ch = ' ';
		if (!fin)
			break;
		temp += ch;
	}
	cout << temp << endl;

	while(i <= temp.size() - 1) {
		if (i!=0 && m % n == 0) {
			fout << temp[i] << endl;
			i++;
			m++;
			if (temp[i] == ' ')
				i++;
		}
		else {
			fout << temp[i];
			i++;
			m++;
		}
	}
	fin.close();
	fout.close();

	return 0;
}