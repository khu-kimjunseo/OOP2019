#include<iostream>
using namespace std;

void sqrt(int* x) {
	*x = *x * *x;
}
int main() {
	int x;
	cout << "input> ";
	cin >> x;
	sqrt(&x);
	
	cout << "������> " << x << endl;
	return 0;
}