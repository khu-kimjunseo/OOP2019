#include<iostream>
#include<string>
using namespace std;

void conver(string* str) {
	string temp;
	cout << "input> ";
	cin >> temp;
	*str = temp;
}

int main() {
	string str = "This is default value";
	cout << "�⺻�� ���> " << str << endl;
	conver(&str);
	cout << "��ȯ�� �� ���> " << str << endl;
	return 0;
}