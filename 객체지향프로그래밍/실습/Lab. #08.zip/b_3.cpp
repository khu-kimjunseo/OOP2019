#include<iostream>
#include<vector>
using namespace std;

void reverse(vector<int>& v) {
	for (int i = 0; i < 5; i++) {
		int temp = v[i];
		v[i] = v[9 - i];
		v[9 - i] = temp;
	}
}

void print( vector<int>& v) {
	for (unsigned i = 0; i < v.size(); i++)
		cout << v[i] << "\t";
	cout << endl;
}

int main() {
	vector<int> v = { 1,2,3,4,5,6,7,8,9,10 };
	cout << "�⺻ Vector ��:" << endl;
	print(v);
	reverse(v);
	cout << "�Լ� ���� �� Vector ��:" << endl;
	print(v);

}