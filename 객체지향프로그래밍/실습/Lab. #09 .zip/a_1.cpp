#include<iostream>
#include<vector>
using namespace std;

int main() {
	vector<vector<int>> vec(2, vector<int>(3));

	for (vector<int>& v : vec) {
		for (int& elem : v) {
			cin >> elem;
		}
	}

	for (vector<int>& v : vec) {
		for (auto elem : v) {
			cout << elem << "\t";
		}
		cout << endl;
	}

	auto a = 10;
	auto b = 10.1;
	auto c = 'd';
	cout << a << ", " << b << ", " << c << endl;

	return 0;
}