#include<iostream>
#include<vector>
using namespace std;

int main() {
	int ary[3] = { 1, 2, 3 };

	cout << (ary + 0) << "\t" << *(ary + 0) << "\t" << ary[0] << endl;
	cout << (ary + 1) << "\t" << *(ary + 1) << "\t" << ary[0] << endl;
	cout << (ary + 2) << "\t" << *(ary + 2) << "\t" << ary[0] << endl;
	return 0;
}