#include<iostream>
#include<vector>
using namespace std;

void print(const int* ar, const int length) {
	for (int i = 0; i < length; i++)
		cout << ar[i] << "\t";
	cout << endl;
}

int sum(int* begin, int* end) {
	int* curr = begin;
	int result = 0;
	while (curr != end) {
		result += *curr;
		curr++;
	}
	return result;
}

int main() {
	int ary[] = { 10, 20, 30, 40, 50 };
	print(ary, 5);

	int* begin, * end;
	begin = ary;
	end = ary + 5;
	cout << sum(begin, end) << endl;

	return 0;
}