#include<iostream>
#include<iomanip>
#include<vector>
using namespace std;

int main() {
	int size;
	cout << "Size: ";
	cin >> size;
	const int len = 10;
	int staticArr[len];

	double* dynamicArr;
	dynamicArr = new double[size];

	for (int i = 0; i < size; i++) {
		cout << "dynamic\t";
	}
	cout << endl;

	delete[] dynamicArr;

	return 0;
}