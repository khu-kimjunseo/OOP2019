#include<iostream>
#include<vector>
using namespace std;

bool found_char(const char* s, char c) {
	while (*s != NULL) {
		if (*s == c)
			return true;
		s++;
	}
	return false;
}

int main() {
	const char* ch = "phrase";

	for (char c = 'a'; c <= 'z'; c++) {
		cout << "[" << c << "] is ";
		if (!found_char(ch, c))
			cout << "NOT ";
		cout << "in " << ch << endl;
	}

	return 0;
}