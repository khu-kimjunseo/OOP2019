#include<iostream>
#include<vector>
using namespace std;

void gen_matrix(vector<vector<int>>& vec, int row, int col) {
	for (unsigned ROW = 0; ROW < row; ROW++) {
		for (unsigned COL = 0; COL < col; COL++) {
			vec[ROW][COL] = rand() & 19 - 9;
		}
	}
}

void print_matrix(const vector<vector<int>>& vec) {
	for (unsigned row = 0; row < vec.size(); row ++) {
		for (unsigned col = 0; row < vec[row].size();col++) {
			cout << vec[row][col] << "\t";
		}
		cout << endl;
	}
}

void multi_matrix(const vector<vector<int>>& A, const vector<vector<int>>& B, int rowA, int rowB, int colA, int colB) {

	if (colA == rowB) {
		vector<vector<int>> result(rowA, vector<int>(colB));
		for (int row = 0; row < rowA; row++) {
			for (int col = 0; col < colB; col++) {
				for (int inner = 0; inner < colA; inner++) {
					result[row][col] += A[row][inner] * B[inner][col];
				}
				cout << result[row][col] << "\t";
			}
			cout << endl;
		}
	}
	else {
		cout << "�� ����� ���� �� �����ϴ�." << endl;
		exit(100);
	}
}

int main() {
	int rowA, colA, rowB, colB;
	cout << "A�� ��, ���� ũ�⸦ �Է����ּ��� : ";
	cin >> rowA >> colA;
	cout << "B�� ��, ���� ũ�⸦ �Է����ּ��� : ";
	cin >> rowB >> colB;
	if (rowA == 0 || colA == 0 || rowB == 0 || colB == 0) {
		cout << "����� ������ �� �����ϴ�." << endl;
		exit(100);
	}

	vector<vector<int>> matA;
	vector<vector<int>> matB;

	gen_matrix(matA, rowA, colA);
	gen_matrix(matB, rowB, colB);

	cout << "A ��� :" << endl;
	print_matrix(matA);
	cout << "B ��� :" << endl;
	print_matrix(matB);

	multi_matrix(matA, matB, rowA, rowB, colA, colB);

	return 0;
}