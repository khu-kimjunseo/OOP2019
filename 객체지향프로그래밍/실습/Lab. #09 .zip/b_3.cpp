#include<iostream>
using namespace std;

int main() {
	while (1) {
		int n;
		cout << "Please enter a number: ";
		cin >> n;
		if (n < 2) {
			cout << "Wrong number!!!" << endl;
			exit(100);
		}

		int size = n / 2;

		int* arr;
		arr = new int[size];

		for (int i = 0; i < size; i++) {
			arr[i] = rand() % n + 1;
		}

		cout << "SIze of random array: " << size << endl;
		cout << "[ Array ]" << endl;

		int a = 0;
		for (int i = 0; i < size - 1; i++) {
			cout << arr[i] << " ";
			if (arr[i] == arr[i + 1])
				a = 1;
		}
		cout << arr[size - 1] << endl;

		if (a == 1)
			cout << "Duplicates found." << endl << endl;
		else
			cout << "Duplicates not found." << endl <<endl ;
	}
}