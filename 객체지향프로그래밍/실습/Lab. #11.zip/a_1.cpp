#include<iostream>
using namespace std;

class Point {
private:
	int x;
	int y;
	static int numCreatedObjects;
	// ifstream fin;
	// int *ary;
public:
	Point() :x(0), y(0) {
		numCreatedObjects++;
		//	fin.open("test.txt");
		//	ary = new int [100];
	}
	Point(int _x, int _y);

	~Point() {
		//	fin.close()
		//	delete[] ary;
		cout << "Destructed..." << endl;
	}

	static int getNumCreatedObject() { return numCreatedObjects; }

	void setXY(int _x, int _y) {
		//this-> ����� �ʱ�ȭ
		this->x = _x;
		this->y = _y;
	}
	int getX() const;
	int getY() const;

	//operator overloading(������ �����ε�)
	Point& operator=(Point& pt) {
		this->x = pt.getX();
		this->y = pt.getY();
		return (*this);
	}
	// *this + pt2 ->
	Point operator+(Point& pt2) {
		Point result(this->x + pt2.getX(), this->y + getY());
		return result;
	}
	friend ostream& operator<<(ostream& cout, Point& pt);
	friend void print(const Point& pt);
	friend class SpyPoint;
};

//static �ɹ� ���� �ʱ�ȭ (numCreatedObjects)
int Point::numCreatedObjects = 0;

Point::Point(int _x, int _y) : x(_x), y(_y) {
	numCreatedObjects++;
}

int Point::getX() const { return x; }
int Point::getY() const { return y; }

//Point operator+(Point& pt1, Point& pt2){
//	Point result(pt1.getX() + pt2.getX(), pt1.getY() + pt2.getY());
//	return result;
//}

//��ü�� const�� �Է¹�����, �ݵ�� const�� ����� �ɹ� �Լ��� ��� ����
void print(const Point& pt) {
	cout << pt.x << ", " << pt.y << endl << endl;
}

ostream& operator<<(ostream& cout, Point& pt) {
	cout << pt.x << ", " << pt.y << endl;
	return cout;
}

class SpyPoint {
public:
	//������ ���� ��� �ǵ��� hack_all_info�Լ� ����

	//Hacked by SpyPoint
	//x: 40
	//y: 60
	//numCreatedObj.:10

	void hack_all_info(const Point& pt) {
		cout << "Hacked by SpyPoint" << endl;
		cout << "x: " << pt.x << endl;
		cout << "y: " << pt.y << endl;
		cout << "numCreatedObj.: " << pt.numCreatedObjects << endl << endl;
	}

	//friend class Point;
};

int main() {
	Point pt1(1, 2);
	cout << "pt1 : ";
	print(pt1);

	//pt1�� ����ϴ� 2���� ��� ����
	Point* pPt1 = &pt1;
	cout << "pt1 : ";
	cout << (*pPt1).getX() << ", " << (*pPt1).getY() << endl;
	cout << "pt1 : ";
	cout << pPt1->getX() << ", " << pPt1->getY() << endl << endl;

	//�������� Point* pPt2 �Ҵ��Ͽ� 10,20 ���� �� -> ����Ͽ� ��� (pt1 ��� ����)
	Point* pPt2 = new Point[1];
	pPt2[0].setXY(10, 20);
	cout << "pt2 : " << pPt2->getX() << ", " << pPt2->getY() << endl;
	delete[] pPt2;

	// Point* pPt3;		pPt3->setXY(5, 6); //���� �ȵ�
	int a = 3 + 5;
	Point pt2(10, 20);
	Point pt3(30, 40);

	//pt4 = pt2, pt3�� ���ϱ�
	Point pt4 = pt2 + pt3;

	cout << "pt2 : " << pt2;	// operator<<(cout, pt2)
	cout << "pt3 : " << pt3;
	cout << "pt4 : " << pt4;

	cout << "pt1 NumCreatedObject : " << pt1.getNumCreatedObject() << endl << endl;

	Point* ptAry = new Point[5];
	cout << "pt2 NumCreatedObject : " << pt2.getNumCreatedObject() << endl << endl;
	delete[] ptAry;

	SpyPoint spy;
	cout << endl << "pt1 info" << endl;
	spy.hack_all_info(pt1);
	cout << "pt4 info" << endl;
	spy.hack_all_info(pt4);

	return 0;
}