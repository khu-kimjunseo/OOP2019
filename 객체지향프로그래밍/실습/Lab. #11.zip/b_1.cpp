#include<iostream>
#include<string>
using namespace std;

class User {
private:
	string ID;
	string Password;
public:
	User() : ID(""), Password("") {}
	User(string id, string password) : ID(id), Password(password) {}

	void setid(string id) {
		ID = id;
	}
	void setpassword(string password) {
		Password = password;
	}

	string getID() { return ID; }
	string getPassword() { return Password; }
};
int main() {
	User user[3];
	string id, password, searchId, searchPassword;
	for (int i = 0; i < 3; i++) {
		cout << "============ " << i + 1 << " ============" << endl;
		cout << "ID : ";
		cin >> id;

		for (int j = 0; j < i; j++) {
			if (id == user[j].getID()) {
				cout << "�̹� �����ϴ� ID�Դϴ�." << endl << "�����մϴ�." << endl;
				exit(100);
			}
		}

		cout << "password : ";
		cin >> password;

		

		user[i].setid(id);
		user[i].setpassword(password);

		cout << "===========================" << endl << endl;



	}
	while (1) {
		cout << "============ Login ============" << endl << endl;
		cout << "ID : ";
		cin >> searchId;

		if (searchId == "����") {
			cout << "�����ϰڽ��ϴ�" << endl;
			exit(100);
		}

		cout << "Password : ";
		cin >> searchPassword;
		int x = 0;

		

		for (int i = 0; i < 3; i++) {
			if (searchId == user[i].getID()) {
				if (searchPassword == user[i].getPassword()) {
					x = 1;
				}
			}
			
		}
		if (x == 1) {
			cout << "�α��� �Ǽ̽��ϴ�." << endl;
			cout << "=========================" << endl << endl;
		}
		else {
			cout << "�߸��� ID�ų� PASSWORD �Դϴ�." << endl;
		}
	}
}