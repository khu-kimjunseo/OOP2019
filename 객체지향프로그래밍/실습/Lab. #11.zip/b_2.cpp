#include<iostream>
#include<cmath>
using namespace std;

class Point {
private:
	int x;
	int y;
public:
	Point() :x(0), y(0) {}
	Point(int _x, int _y) :x(_x), y(_y) {}

	void setPoint(int _x, int _y) {
		x = _x;
		y = _y;
	}

	int getX() const { return x; }
	int getY() const { return y; }

	Point operator-(const Point& pt) {
		Point result(this->x - pt.getX(), this->y - pt.getY());
		return result;
	}

	Point operator*(const Point& pt) {
		Point result(this->x * pt.getX(), this->y * pt.getY());
		return result;
	}
};

int main() {
	int x1 = 0, y1 = 0, x2 = 0, y2 = 0;
	Point* pP1, * pP2, * pP3;

	cout << "ù��° ��ǥ (x1, y1)�� �Է��ϼ��� : ";
	cin >> x1 >> y1;
	cout << "�ι�° ��ǥ (x2, y2)�� �Է��ϼ��� : ";
	cin >> x2 >> y2;
	
	pP1 = new Point(x1, y1);
	pP2 = new Point(x2, y2);
	pP3 = new Point();
	
	*pP3 = (*pP1 - *pP2) * (*pP1 - *pP2);
	
	double length;
	length = sqrt(pP3->getX() + pP3->getY());
	
	
	
	cout << "�� ��ǥ ������ ���̴� " << length <<  "�Դϴ�." << endl;

	return 0;
}