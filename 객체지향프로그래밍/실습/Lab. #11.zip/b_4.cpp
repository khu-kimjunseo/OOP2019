#include<iostream>
#include<string>
using namespace std;

class Account {
private:
	string name;
	string id;
	int money;
	static int countStu;
public:
	~Account() { }
	Account() : name(""), id(""), money(0) {
		countStu++;
	}

	void setName(string _name) { name = _name; }
	void setID(string _ID) { id = _ID; }
	void setMoney(int _money) { money = _money; }

	int getcountStu() { return countStu; }
	int getMoney() { return money; }
	string getID() { return id; }
};
int Account::countStu = 0;

int main() {
	int count, _money;
	string _name, _id;
	cout << "�� �л� �� �Է�: ";
	cin >> count;

	Account* acnt = new Account[count]; //countStu = 3

	for (int i = 0; i < count; i++) {
		cout << i + 1 << "��° �л� ���� �Է� : " << endl;
		cout << "�й� : ";
		cin >> _id;
		if (i != 0) {
			for (int j = 0; j < i; j++) {
				if (_id == acnt[j].getID()) {
					cout << "�ߺ��� �й��Դϴ�." << endl;
					exit(100);
				}
			}
		}
		acnt[i].setID(_id);
		cout << endl << "�̸� : ";
		cin >> _name;
		acnt[i].setName(_name);
		cout << endl << "�ܾ� : ";
		cin >> _money;
		acnt[i].setMoney(_money);
		cout << "==============================" << endl << endl;
	}

	_money = 0;
	for (int i = 0; i < count; i++) {
		_money = _money + acnt[i].getMoney();
	}
	delete[] acnt;
	cout << "ȸ���� �ݾ� : " << _money << endl;
}