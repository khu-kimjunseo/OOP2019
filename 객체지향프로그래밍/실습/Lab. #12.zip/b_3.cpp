#include<iostream>
using namespace std;

class Train {
public:
	Train() {}
	Train(int people) { mPeople = people; }
	~Train() {}
	virtual int station(int takeOff, int takeOn) {
		mPeople = mPeople - takeOff + takeOn;
		return mPeople;
	}
protected:
	int mPeople;
};

class Ktx :public Train {
public:
	Ktx() :Train::Train(0) {}
	Ktx(int people) :Train::Train(people) {}
	~Ktx() {}

	int station(int takeOff, int takeOn) override {
		mPeople = mPeople - takeOff + takeOn;
		return mPeople;
	}
	int getPeople() {
		return mPeople;
	}
};

int main() {
	Ktx k;
	int takeon, takeoff, result = 0;
	for (int i = 0; i < 5; i++) {
		cout << i + 1 << "����: ";
		cin >> takeon >> takeoff;
		if (k.station(takeon, takeoff) < 0) {
			cout << "�����̴��Դϴ�." << endl;
			exit(100);
		}
		else if (k.getPeople() > 300) {
			cout << "�����ʰ��Դϴ�." << endl;
			exit(100);
		}
		if (result < k.getPeople())
			result = k.getPeople();
		
	}
	cout << "���� ���� ����� ž�� ���� ���� ��� ��: " << result << endl;
}