#include"ApplicationType.h"

int main() {
	ApplicationType appType;
	appType.run();
	return 0;
}