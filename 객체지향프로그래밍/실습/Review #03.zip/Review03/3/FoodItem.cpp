#include "FoodItem.h"

int FoodItem::getDueDate() { return dueDate; }
void FoodItem::displayItem() const {
	cout << this->code << setw(10) << this->name << setw(10) << this->price << setw(10) << this->dueDate << endl;
}
int FoodItem:: readItemFromFile(ifstream & _fin) {
	_fin.open("foodIteam.txt");

}
int FoodItem::writeItemToFile(ofstream& _fout) {}