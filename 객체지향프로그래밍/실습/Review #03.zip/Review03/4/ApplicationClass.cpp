#include "ApplicationClass.h"

ApplicationClass::ApplicationClass(string office, string food) : officeItemFileName(office), foodItemFileName(food) {
	finof.open(officeItemFileName);
	finfo.open(foodItemFileName);
};

string ApplicationClass::getCommand() {
	string cmd;
	cout << "Input>";
	cin >> cmd;
	return cmd;
}
void displayAllItems() {
	while () {

	}
}
void displayFoodItems() {};
void displayOfficeItems() {};

void ApplicationClass::run() {
	string sOption;
	while (1) {
		sOption = getCommand();
		if (sOption == "1")	displayAllItems();
		else if (sOption == "2") displayFoodItems();
		else if (sOption == "3") displayOfficeItems();
		else if (sOption == "4") searchItemByCode();
		else if (sOption == "5") break;
	}
	cout << "Exit the program..." << endl;
}