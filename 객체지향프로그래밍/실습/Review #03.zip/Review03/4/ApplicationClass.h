#pragma once
#include<iostream>
#include<vector>
#include<string>
#include<fstream>
using namespace std;
class ApplicationClass
{
private:
	vector<Item*> vItem;
	string officeItemFileName;
	string foodItemFileName;
	ifstream finof;
	ifstream finfo;
public:
	ApplicationClass(string office, string food) {};
	void run() {};
	void displayAllItems() {};
	void displayFoodItems() {};
	void displayOfficeItems() {};
	string getCommand() {};
	
};

